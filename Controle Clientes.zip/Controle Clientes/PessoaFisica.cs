namespace Controle_Clientes {
    public class PessoaFisica : Clientes {
        public string cpf {get; set;}
        public string rg {get; set;}
    }
}